package jugglemasterpro.control.file;

import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JToolTip;
import jugglemasterpro.control.ControlJFrame;
import jugglemasterpro.control.util.MenusTools;
import jugglemasterpro.util.Constants;
import jugglemasterpro.util.Tools;

final public class RecentFilesExtendedJMenu extends ExtendedJMenu {

	public RecentFilesExtendedJMenu(ControlJFrame objPcontrolJFrame) {
		super(objPcontrolJFrame, ExtendedJMenu.bytS_RECENT, Constants.intS_FILE_ICON_RECENT);
		this.strGfileNameAL = new ArrayList<String>(1);
		this.strGfileTitleAL = new ArrayList<String>(1);
		this.objGimageIconAL = new ArrayList<ImageIcon>(1);
		this.bolGnewListsBooleanAL = new ArrayList<Boolean>(1);
		this.bolGsiteswapsBooleanAL = new ArrayList<Boolean>(1);
		this.bolGstylesBooleanAL = new ArrayList<Boolean>(1);
		this.setFont(this.objGcontrolJFrame.getFont());
		this.setOpaque(true);
	}

	// final public void doAddRecentFile(String strPfileName, String strPfileTitle, boolean bolPnewLists,
	// boolean bolPsiteswaps, boolean bolPstyles) {
	//
	// this.doAddRecentFile(
	// strPfileName,
	// strPfileTitle,
	// this.objGcontrolJFrame.getFileImageIcon(bolPnewLists, bolPsiteswaps, bolPstyles),
	// bolPnewLists,
	// bolPsiteswaps,
	// bolPstyles);
	// }
	//
	@Override final public JToolTip createToolTip() {
		return Tools.getJuggleToolTip(this.objGcontrolJFrame);
	}

	/**
	 * Method description
	 * 
	 * @see
	 * @param intPaction
	 */
	final public void doAddRecentFile(	String strPfileName,
										String strPfileTitle,
										ImageIcon icoP,
										boolean bolPnewLists,
										boolean bolPsiteswaps,
										boolean bolPstyles) {

		if (this.objGcontrolJFrame.getPatternsManager().bytGpatternsManagerType == Constants.bytS_MANAGER_FILES_PATTERNS) {
			this.strGfileNameAL.add(0, strPfileName);
			this.strGfileTitleAL.add(0, strPfileTitle);
			this.objGimageIconAL.add(0, icoP);
			this.bolGnewListsBooleanAL.add(0, bolPnewLists);
			this.bolGsiteswapsBooleanAL.add(0, bolPsiteswaps);
			this.bolGstylesBooleanAL.add(0, bolPstyles);

			// Suppress multiple occurences of same files :
			int intLcomparedIndex = 0;
			while (intLcomparedIndex < this.strGfileNameAL.size()) {
				int intLcomparingIndex = intLcomparedIndex + 1;
				while (intLcomparingIndex < this.strGfileNameAL.size()) {
					if (this.strGfileNameAL.get(intLcomparingIndex).equals(this.strGfileNameAL.get(intLcomparedIndex))
						&& this.strGfileTitleAL.get(intLcomparingIndex).equals(this.strGfileTitleAL.get(intLcomparedIndex))
						&& this.bolGnewListsBooleanAL.get(intLcomparingIndex).equals(this.bolGnewListsBooleanAL.get(intLcomparedIndex))
						&& this.bolGsiteswapsBooleanAL.get(intLcomparingIndex).equals(this.bolGsiteswapsBooleanAL.get(intLcomparedIndex))
						&& this.bolGstylesBooleanAL.get(intLcomparingIndex).equals(this.bolGstylesBooleanAL.get(intLcomparedIndex))) {
						this.strGfileNameAL.remove(intLcomparingIndex);
						this.strGfileTitleAL.remove(intLcomparingIndex);
						this.objGimageIconAL.remove(intLcomparingIndex);
						this.bolGnewListsBooleanAL.remove(intLcomparingIndex);
						this.bolGsiteswapsBooleanAL.remove(intLcomparingIndex);
						this.bolGstylesBooleanAL.remove(intLcomparingIndex);
					} else {
						intLcomparingIndex++;
					}
				}
				intLcomparedIndex++;
			}

			// Build the recent file menu :
			int intLrecentFilesNumber = this.strGfileNameAL.size();
			if (intLrecentFilesNumber > Constants.bytS_UNCLASS_MAXIMUM_RECENT_FILES_NUMBER) {
				for (int intLindex = Constants.bytS_UNCLASS_MAXIMUM_RECENT_FILES_NUMBER; intLindex < intLrecentFilesNumber; ++intLindex) {
					this.strGfileNameAL.remove(intLindex);
					this.strGfileTitleAL.remove(intLindex);
					this.objGimageIconAL.remove(intLindex);
					this.bolGnewListsBooleanAL.remove(intLindex);
					this.bolGsiteswapsBooleanAL.remove(intLindex);
					this.bolGstylesBooleanAL.remove(intLindex);
				}
				intLrecentFilesNumber = Constants.bytS_UNCLASS_MAXIMUM_RECENT_FILES_NUMBER;
			}
			this.removeAll();
			for (int intLrecentFileIndex = 0; intLrecentFileIndex < intLrecentFilesNumber; ++intLrecentFileIndex) {
				final PatternsFileJCheckBoxMenuItem objLrecentPatternsFileJCheckBoxMenuItem =
																								new PatternsFileJCheckBoxMenuItem(	this.objGcontrolJFrame,
																																	this.strGfileTitleAL.get(intLrecentFileIndex),
																																	this.strGfileTitleAL.get(intLrecentFileIndex),
																																	this.strGfileNameAL.get(intLrecentFileIndex),
																																	this.objGimageIconAL.get(intLrecentFileIndex),
																																	this.bolGnewListsBooleanAL.get(intLrecentFileIndex),
																																	this.bolGsiteswapsBooleanAL.get(intLrecentFileIndex),
																																	this.bolGstylesBooleanAL.get(intLrecentFileIndex),
																																	(byte) intLrecentFileIndex);
				MenusTools.setNoMnemonicLabel(objLrecentPatternsFileJCheckBoxMenuItem, this.strGfileTitleAL.get(intLrecentFileIndex));
				objLrecentPatternsFileJCheckBoxMenuItem.setIcon(this.objGimageIconAL.get(intLrecentFileIndex));
				objLrecentPatternsFileJCheckBoxMenuItem.setToolTipText(this.strGfileNameAL.get(intLrecentFileIndex));
				this.add(objLrecentPatternsFileJCheckBoxMenuItem);
			}
		}
	}

	final public void setEnabled() {
		this.setEnabled(this.strGfileNameAL.size() > 0);
	}

	private final ArrayList<Boolean>	bolGnewListsBooleanAL;
	private final ArrayList<Boolean>	bolGsiteswapsBooleanAL;
	private final ArrayList<Boolean>	bolGstylesBooleanAL;

	private final ArrayList<ImageIcon>	objGimageIconAL;

	private final ArrayList<String>		strGfileNameAL;

	private final ArrayList<String>		strGfileTitleAL;

	final private static long			serialVersionUID	= Constants.lngS_ENGINE_VERSION_NUMBER;
}
