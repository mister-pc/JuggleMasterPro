/**
 * 
 */
package jugglemasterpro.control.criteria;

import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ItemEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import jugglemasterpro.control.ControlJFrame;
import jugglemasterpro.user.Preferences;
import jugglemasterpro.util.Constants;
import jugglemasterpro.util.Tools;

/**
 * @author BeLO
 */
public class MarkCanvas extends Canvas implements MouseListener {

	private static Image		imgSmark;
	private static Image		imgSmarkBW;

	final private static long	serialVersionUID	= Constants.lngS_ENGINE_VERSION_NUMBER;

	private boolean				bolGenabled;

	private final boolean		bolGpreferences;

	private Image				imgGcurrent;

	private final int			intGdisabledLanguageIndex;

	final private int			intGenabledLanguageIndex;
	private final ControlJFrame	objGcontrolJFrame;

	public MarkCanvas(	ControlJFrame objPcontrolJFrame,
						boolean bolPlistener,
						boolean bolPpreferences,
						int intPtooltipEnabledLanguageIndex,
						int intPtooltipDisabledLanguageIndex) {
		this.objGcontrolJFrame = objPcontrolJFrame;
		this.setSize(new Dimension(16, 16));
		this.bolGenabled = false;
		this.bolGpreferences = bolPpreferences;
		this.intGenabledLanguageIndex = intPtooltipEnabledLanguageIndex;
		this.intGdisabledLanguageIndex = intPtooltipDisabledLanguageIndex;
		if (bolPlistener) {
			this.addMouseListener(this);
		}
	}

	/**
	 * @param objPcontrolJFrame
	 */
	public MarkCanvas(ControlJFrame objPcontrolJFrame, int intPtooltipEnabledLanguageIndex) {
		this(objPcontrolJFrame, false, false, intPtooltipEnabledLanguageIndex, Constants.bytS_UNCLASS_NO_VALUE);
	}

	final public void doLoadImages() {
		if (MarkCanvas.imgSmark == null) {
			MarkCanvas.imgSmark = this.objGcontrolJFrame.getJuggleMasterPro().getImage(Constants.intS_FILE_ICON_MARK, 1);
		}
		if (MarkCanvas.imgSmarkBW == null) {
			MarkCanvas.imgSmarkBW = this.objGcontrolJFrame.getJuggleMasterPro().getImage(Constants.intS_FILE_ICON_MARK_BW, 1);
		}
		this.setEnabled(this.bolGenabled);
	}

	@Override final public void mouseClicked(MouseEvent objPmouseEvent) {

		if (this.bolGpreferences) {
			if (this.objGcontrolJFrame.objGpreferencesJDialog != null) {
				Tools.debug("MarkCanvas.mouseClicked(preferencesJDialog)");
				final ItemEvent objLitemEvent =
												new ItemEvent(	this.objGcontrolJFrame.objGpreferencesJDialog.objGbooleanGlobalJCheckBoxA[Constants.bytS_BOOLEAN_GLOBAL_MARK],
																ItemEvent.ITEM_STATE_CHANGED,
																this,
																Preferences.getGlobalBooleanPreference(Constants.bytS_BOOLEAN_GLOBAL_MARK)
																																			? ItemEvent.DESELECTED
																																			: ItemEvent.SELECTED);

				this.objGcontrolJFrame.objGpreferencesJDialog.doApplyBooleanGlobalCheckChange(	Constants.bytS_BOOLEAN_GLOBAL_MARK,
																								!Preferences.getGlobalBooleanPreference(Constants.bytS_BOOLEAN_GLOBAL_MARK));
				this.objGcontrolJFrame.objGpreferencesJDialog.objGbooleanGlobalJCheckBoxA[Constants.bytS_BOOLEAN_GLOBAL_MARK].itemStateChanged(objLitemEvent);

			}
			return;
		}

		Tools.debug("MarkCanvas.mouseClicked(controlJFrame)");
		final ItemEvent objLitemEvent =
										new ItemEvent(	this.objGcontrolJFrame.objGmarkJCheckBox,
														ItemEvent.ITEM_STATE_CHANGED,
														this,
														Preferences.getGlobalBooleanPreference(Constants.bytS_BOOLEAN_GLOBAL_MARK)
																																	? ItemEvent.DESELECTED
																																	: ItemEvent.SELECTED);
		this.objGcontrolJFrame.objGmarkJCheckBox.itemStateChanged(objLitemEvent);
		return;
	}

	@Override final public void mouseEntered(MouseEvent objPmouseEvent) {}

	@Override final public void mouseExited(MouseEvent objPmouseEvent) {}

	@Override final public void mousePressed(MouseEvent objPmouseEvent) {}

	@Override final public void mouseReleased(MouseEvent objPmouseEvent) {}

	@Override final public void paint(Graphics objPgraphics) {
		objPgraphics.drawImage(this.imgGcurrent, 0, 0, null);
	}

	@Override final public void setEnabled(boolean bolPenabled) {

		this.bolGenabled = bolPenabled;
		this.imgGcurrent = this.bolGenabled ? MarkCanvas.imgSmark : MarkCanvas.imgSmarkBW;
		final boolean bolLedition =
									this.objGcontrolJFrame.isControlSelected(Constants.bytS_BOOLEAN_LOCAL_EDITION)
										|| this.objGcontrolJFrame.isBooleanLocal(Constants.bytS_BOOLEAN_LOCAL_EDITION);
		super.setEnabled(bolLedition);
		this.repaint();
	}

	final public void setToolTipText() {
	// this.setToolTipText(this.objGcontrolJFrame.getLanguageString(this.bolGenabled
	// || this.intGdisabledLanguageIndex == Constants.bytS_UNCLASS_NO_VALUE
	// ? this.intGenabledLanguageIndex
	// : this.intGdisabledLanguageIndex));
	}
}
