/*
 * @(#)LinksJMenuItemActionListener.java 4.3.0
 * Copyleft (c) 2010 Arnaud BeLO.
 */

package jugglemasterpro.control.help;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import jugglemasterpro.control.ControlJFrame;
import jugglemasterpro.util.Constants;
import jugglemasterpro.util.Tools;

/**
 * Description
 * 
 * @version 4.3.0
 * @author Arnaud BeLO.
 */
final public class LinksJMenuItemActionListener implements ActionListener {

	/**
	 * Constructs
	 * 
	 * @param objPcontrolJFrame
	 * @param strPlinkAddress
	 * @param bolPopenWithDefaultApplication
	 */
	public LinksJMenuItemActionListener(ControlJFrame objPcontrolJFrame, String strPlinkAddress, boolean bolPopenWithDefaultApplication) {
		this.objGcontrolJFrame = objPcontrolJFrame;
		this.strGlinkAddress = strPlinkAddress;
		this.bolGopenWithDefaultApplication = bolPopenWithDefaultApplication;
	}

	/**
	 * Method description
	 * 
	 * @see
	 * @param objPactionEvent
	 */
	@Override final public void actionPerformed(ActionEvent objPactionEvent) {
		Tools.debug("LinksJMenuItemActionListener.actionPerformed()");
		this.objGcontrolJFrame.doHidePopUps();
		HelpActions.doOpenHyperlink(this.objGcontrolJFrame, this.strGlinkAddress, this.bolGopenWithDefaultApplication);
	}

	final private static long	serialVersionUID	= Constants.lngS_ENGINE_VERSION_NUMBER;
	final private boolean		bolGopenWithDefaultApplication;

	final private ControlJFrame	objGcontrolJFrame;

	final private String		strGlinkAddress;
}

/*
 * @(#)LinksJMenuItemActionListener.java 4.3.0
 * Copyleft (c) 2010 Arnaud BeLO.
 */
