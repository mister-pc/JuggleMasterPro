package jugglemasterpro.control.criteria;

import java.awt.event.ActionListener;
import jugglemasterpro.control.ControlJFrame;
import jugglemasterpro.control.util.ExtendedJButton;
import jugglemasterpro.util.Constants;

final public class CriteriaJButton extends ExtendedJButton {

	final private static long	serialVersionUID	= Constants.lngS_ENGINE_VERSION_NUMBER;
	final private boolean		bolGalwaysEnabled;
	final private int			intGtooltip;

	public CriteriaJButton(ControlJFrame objPcontrolJFrame, int intPtooltip) {
		this(objPcontrolJFrame, intPtooltip, false, null);
	}

	public CriteriaJButton(ControlJFrame objPcontrolJFrame, int intPtooltip, ActionListener objPactionListener) {
		this(objPcontrolJFrame, intPtooltip, false, objPactionListener);
	}

	public CriteriaJButton(ControlJFrame objPcontrolJFrame, int intPtooltip, boolean bolPalwaysEnabled) {
		this(objPcontrolJFrame, intPtooltip, bolPalwaysEnabled, null);
	}

	public CriteriaJButton(ControlJFrame objPcontrolJFrame, int intPtooltip, boolean bolPalwaysEnabled, ActionListener objPactionListener) {
		super(objPcontrolJFrame, objPactionListener);
		this.intGtooltip = intPtooltip;
		this.bolGalwaysEnabled = bolPalwaysEnabled;
	}

	final public void setToolTipText() {
		int intLtooltip = Constants.bytS_UNCLASS_NO_VALUE;
		if (this.bolGalwaysEnabled || this.objGcontrolJFrame.objGfindJDialog.isAble()) {
			intLtooltip = this.intGtooltip;
		}
		this.setToolTipText(intLtooltip != Constants.bytS_UNCLASS_NO_VALUE ? this.objGcontrolJFrame.getLanguageString(intLtooltip) : null);
	}
}
