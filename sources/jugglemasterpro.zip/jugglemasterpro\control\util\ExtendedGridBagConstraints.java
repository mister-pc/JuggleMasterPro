/*
 * @(#)ExtendedGridBagConstraints.java 4.3.0
 * Copyleft (c) 2010 Arnaud BeLO.
 */

package jugglemasterpro.control.util;

import java.awt.GridBagConstraints;
import java.awt.Insets;
import jugglemasterpro.util.Constants;
import jugglemasterpro.util.Tools;

/**
 * Description
 * 
 * @version 4.3.0
 * @author Arnaud BeLO.
 */
final public class ExtendedGridBagConstraints extends GridBagConstraints {

	final private static long	serialVersionUID	= Constants.lngS_ENGINE_VERSION_NUMBER;

	/**
	 * Constructs
	 * 
	 * @param intPgridX
	 * @param intPgridY
	 * @param intPgridWidth
	 * @param intPgridHeight
	 * @param intPinsideLocation
	 * @param intPinsideSpaceX
	 * @param intPinsideSpaceY
	 * @param intPtopMargin
	 * @param intPbottomMargin
	 * @param intPleftMargin
	 * @param intPrightMargin
	 * @param intPfill
	 * @param dblPweightX
	 * @param dblPweightY
	 */

	public ExtendedGridBagConstraints(int intPfill, double dblPweightX, double dblPweightY) {
		this(	GridBagConstraints.RELATIVE,
				GridBagConstraints.RELATIVE,
				1,
				1,
				GridBagConstraints.WEST,
				0,
				0,
				0,
				0,
				0,
				0,
				intPfill,
				dblPweightX,
				dblPweightY);
	}

	// = new ExtendedGridBagConstraints(
	// intPgridX,
	// intPgridY,
	// intPgridWidth,
	// intPgridHeight,
	// [ intPinsideLocation = ExtendedGridBagConstraints.WEST,
	// [ intPinsideSpaceX = 0,
	// intPinsideSpaceY = 0 ] ],
	// [ intPtopMargin = 0,
	// intPbottomMargin = 0,
	// intPleftMargin = 0,
	// intPrightMargin = 0 ],
	// [ intPfill = ExtendedGridBagConstraints.NONE,
	// dblPweightX = 0.0F,
	// dblPweightY = 0.0F ])

	public ExtendedGridBagConstraints( // 4
										int intPgridX,
										int intPgridY,
										int intPgridWidth,
										int intPgridHeight) {
		this(intPgridX, intPgridY, intPgridWidth, intPgridHeight, GridBagConstraints.WEST, 0, 0, 0, 0, 0, 0, GridBagConstraints.NONE, 0.0F, 0.0F);
	}

	public ExtendedGridBagConstraints( // 5
										int intPgridX,
										int intPgridY,
										int intPgridWidth,
										int intPgridHeight,
										int intPinsideLocation) {
		this(intPgridX, intPgridY, intPgridWidth, intPgridHeight, intPinsideLocation, 0, 0, 0, 0, 0, 0, GridBagConstraints.NONE, 0.0F, 0.0F);
	}

	public ExtendedGridBagConstraints( // 5 + 2
										int intPgridX,
										int intPgridY,
										int intPgridWidth,
										int intPgridHeight,
										int intPfill,
										double dblPweightX,
										double dblPweightY) {
		this(intPgridX, intPgridY, intPgridWidth, intPgridHeight, GridBagConstraints.WEST, 0, 0, 0, 0, 0, 0, intPfill, dblPweightX, dblPweightY);
	}

	public ExtendedGridBagConstraints( // 6 + 2
										int intPgridX,
										int intPgridY,
										int intPgridWidth,
										int intPgridHeight,
										int intPinsideLocation,
										int intPfill,
										double dblPweightX,
										double dblPweightY) {
		this(intPgridX, intPgridY, intPgridWidth, intPgridHeight, intPinsideLocation, 0, 0, 0, 0, 0, 0, intPfill, dblPweightX, dblPweightY);
	}

	public ExtendedGridBagConstraints( // 7
										int intPgridX,
										int intPgridY,
										int intPgridWidth,
										int intPgridHeight,
										int intPinsideLocation,
										int intPinsideSpaceX,
										int intPinsideSpaceY) {
		this(	intPgridX,
				intPgridY,
				intPgridWidth,
				intPgridHeight,
				intPinsideLocation,
				intPinsideSpaceX,
				intPinsideSpaceY,
				0,
				0,
				0,
				0,
				GridBagConstraints.NONE,
				0.0F,
				0.0F);
	}

	public ExtendedGridBagConstraints( // 8
										int intPgridX,
										int intPgridY,
										int intPgridWidth,
										int intPgridHeight,
										int intPtopMargin,
										int intPbottomMargin,
										int intPleftMargin,
										int intPrightMargin) {
		this(	intPgridX,
				intPgridY,
				intPgridWidth,
				intPgridHeight,
				GridBagConstraints.WEST,
				0,
				0,
				intPtopMargin,
				intPbottomMargin,
				intPleftMargin,
				intPrightMargin,
				GridBagConstraints.NONE,
				0.0F,
				0.0F);
	}

	public ExtendedGridBagConstraints( // 8 + 2
										int intPgridX,
										int intPgridY,
										int intPgridWidth,
										int intPgridHeight,
										int intPinsideLocation,
										int intPinsideSpaceX,
										int intPinsideSpaceY,
										int intPfill,
										double dblPweightX,
										double dblPweightY) {
		this(	intPgridX,
				intPgridY,
				intPgridWidth,
				intPgridHeight,
				intPinsideLocation,
				intPinsideSpaceX,
				intPinsideSpaceY,
				0,
				0,
				0,
				0,
				intPfill,
				dblPweightX,
				dblPweightY);
	}

	public ExtendedGridBagConstraints( // 9
										int intPgridX,
										int intPgridY,
										int intPgridWidth,
										int intPgridHeight,
										int intPinsideLocation,
										int intPtopMargin,
										int intPbottomMargin,
										int intPleftMargin,
										int intPrightMargin) {
		this(	intPgridX,
				intPgridY,
				intPgridWidth,
				intPgridHeight,
				intPinsideLocation,
				0,
				0,
				intPtopMargin,
				intPbottomMargin,
				intPleftMargin,
				intPrightMargin,
				GridBagConstraints.NONE,
				0.0F,
				0.0F);
	}

	public ExtendedGridBagConstraints( // 9 + 2
										int intPgridX,
										int intPgridY,
										int intPgridWidth,
										int intPgridHeight,
										int intPtopMargin,
										int intPbottomMargin,
										int intPleftMargin,
										int intPrightMargin,
										int intPfill,
										double dblPweightX,
										double dblPweightY) {
		this(	intPgridX,
				intPgridY,
				intPgridWidth,
				intPgridHeight,
				GridBagConstraints.WEST,
				0,
				0,
				intPtopMargin,
				intPbottomMargin,
				intPleftMargin,
				intPrightMargin,
				intPfill,
				dblPweightX,
				dblPweightY);
	}

	public ExtendedGridBagConstraints( // 10 + 2
										int intPgridX,
										int intPgridY,
										int intPgridWidth,
										int intPgridHeight,
										int intPinsideLocation,
										int intPtopMargin,
										int intPbottomMargin,
										int intPleftMargin,
										int intPrightMargin,
										int intPfill,
										double dblPweightX,
										double dblPweightY) {
		this(	intPgridX,
				intPgridY,
				intPgridWidth,
				intPgridHeight,
				intPinsideLocation,
				0,
				0,
				intPtopMargin,
				intPbottomMargin,
				intPleftMargin,
				intPrightMargin,
				intPfill,
				dblPweightX,
				dblPweightY);
	}

	public ExtendedGridBagConstraints( // 11
										int intPgridX,
										int intPgridY,
										int intPgridWidth,
										int intPgridHeight,
										int intPinsideLocation,
										int intPinsideSpaceX,
										int intPinsideSpaceY,
										int intPtopMargin,
										int intPbottomMargin,
										int intPleftMargin,
										int intPrightMargin) {
		this(	intPgridX,
				intPgridY,
				intPgridWidth,
				intPgridHeight,
				intPinsideLocation,
				intPinsideSpaceX,
				intPinsideSpaceY,
				intPtopMargin,
				intPbottomMargin,
				intPleftMargin,
				intPrightMargin,
				GridBagConstraints.NONE,
				0.0F,
				0.0F);
	}

	public ExtendedGridBagConstraints( // 12 + 2
										int intPgridX,
										int intPgridY,
										int intPgridWidth,
										int intPgridHeight,
										int intPinsideLocation,
										int intPinsideSpaceX,
										int intPinsideSpaceY,
										int intPtopMargin,
										int intPbottomMargin,
										int intPleftMargin,
										int intPrightMargin,
										int intPfill,
										double dblPweightX,
										double dblPweightY) {

		this.setGridBounds(intPgridX, intPgridY, intPgridWidth, intPgridHeight);
		this.setInside(intPinsideLocation, intPinsideSpaceX, intPinsideSpaceY);
		this.setMargins(intPtopMargin, intPbottomMargin, intPleftMargin, intPrightMargin);
		this.setFilling(intPfill, dblPweightX, dblPweightY);

	}

	/**
	 * Method description
	 * 
	 * @see
	 * @param intPfill
	 * @param dblPweightX
	 * @param dblPweightY
	 * @return
	 */
	final public ExtendedGridBagConstraints setFilling(int intPfill, double dblPweightX, double dblPweightY) {
		switch (intPfill) {
			case GridBagConstraints.NONE:
			case GridBagConstraints.HORIZONTAL:
			case GridBagConstraints.VERTICAL:
			case GridBagConstraints.BOTH:
				this.fill = intPfill;
				break;
			default:
				Tools.errors("bad grid filling value : ", intPfill);
				break;
		}

		if (dblPweightX >= 0 && dblPweightY >= 0) {
			this.weightx = dblPweightX;
			this.weighty = dblPweightY;
		} else {
			Tools.errors("bad weight value : (", dblPweightX, ", ", dblPweightY, ')');
		}
		return this;
	}

	/**
	 * Method description
	 * 
	 * @see
	 * @param intPgridX
	 * @param intPgridY
	 * @param intPgridWidth
	 * @param intPgridHeight
	 * @return
	 */
	final public ExtendedGridBagConstraints setGridBounds(int intPgridX, int intPgridY, int intPgridWidth, int intPgridHeight) {
		this.setGridLocation(intPgridX, intPgridY);
		this.setGridSize(intPgridWidth, intPgridHeight);
		return this;
	}

	/**
	 * Method description
	 * 
	 * @see
	 * @param intPgridX
	 * @param intPgridY
	 * @return
	 */
	final public ExtendedGridBagConstraints setGridLocation(int intPgridX, int intPgridY) {
		if (intPgridX >= 0 || intPgridX == GridBagConstraints.RELATIVE) {
			this.gridx = intPgridX;
		} else {
			Tools.errors("bad horizontal grid position : ", intPgridX);
		}
		if (intPgridY >= 0 || intPgridY == GridBagConstraints.RELATIVE) {
			this.gridy = intPgridY;
		} else {
			Tools.errors("bad vertical grid position : ", intPgridY);
		}
		return this;
	}

	/**
	 * Method description
	 * 
	 * @see
	 * @param intPgridWidth
	 * @param intPgridHeight
	 * @return
	 */
	final public ExtendedGridBagConstraints setGridSize(int intPgridWidth, int intPgridHeight) {
		if (intPgridWidth > 0 || intPgridWidth == GridBagConstraints.REMAINDER || intPgridWidth == GridBagConstraints.RELATIVE) {
			this.gridwidth = intPgridWidth;
		} else {
			Tools.errors("Bad horizontal width value : ", intPgridWidth);
		}
		if (intPgridHeight > 0 || intPgridHeight == GridBagConstraints.REMAINDER || intPgridHeight == GridBagConstraints.RELATIVE) {
			this.gridheight = intPgridHeight;
		} else {
			Tools.errors("Bad vertical width value : ", intPgridHeight);
		}
		return this;
	}

	/**
	 * Method description
	 * 
	 * @see
	 * @param intPinsideLocation
	 * @param intPinsideSpaceX
	 * @param intPinsideSpaceY
	 * @return
	 */
	final public ExtendedGridBagConstraints setInside(int intPinsideLocation, int intPinsideSpaceX, int intPinsideSpaceY) {
		switch (intPinsideLocation) {
			case GridBagConstraints.PAGE_START:
			case GridBagConstraints.PAGE_END:
			case GridBagConstraints.LINE_START:
			case GridBagConstraints.LINE_END:
			case GridBagConstraints.FIRST_LINE_START:
			case GridBagConstraints.FIRST_LINE_END:
			case GridBagConstraints.LAST_LINE_START:
			case GridBagConstraints.LAST_LINE_END:
			case GridBagConstraints.BASELINE:
			case GridBagConstraints.BASELINE_LEADING:
			case GridBagConstraints.BASELINE_TRAILING:
			case GridBagConstraints.ABOVE_BASELINE:
			case GridBagConstraints.ABOVE_BASELINE_LEADING:
			case GridBagConstraints.ABOVE_BASELINE_TRAILING:
			case GridBagConstraints.BELOW_BASELINE:
			case GridBagConstraints.BELOW_BASELINE_LEADING:
			case GridBagConstraints.BELOW_BASELINE_TRAILING:
				Tools.errors("strange grid anchor value : ", intPinsideLocation);
				//$FALL-THROUGH$
			case GridBagConstraints.CENTER:
			case GridBagConstraints.NORTH:
			case GridBagConstraints.NORTHWEST:
			case GridBagConstraints.NORTHEAST:
			case GridBagConstraints.SOUTH:
			case GridBagConstraints.SOUTHWEST:
			case GridBagConstraints.SOUTHEAST:
			case GridBagConstraints.WEST:
			case GridBagConstraints.EAST:
				this.anchor = intPinsideLocation;
				break;
			default:
				Tools.errors("bad grid anchor value : ", intPinsideLocation);
		}

		if (intPinsideSpaceX >= 0) {
			this.ipadx = intPinsideSpaceX;
		} else {
			Tools.errors("bad horizontal padding value : ", intPinsideSpaceX);
		}
		if (intPinsideSpaceY >= 0) {
			this.ipady = intPinsideSpaceY;
		} else {
			Tools.errors("bad horizontal padding value : ", intPinsideSpaceY);
		}
		return this;
	}

	/**
	 * Method description
	 * 
	 * @see
	 * @param intPtop
	 * @param intPbottom
	 * @param intPleft
	 * @param intPright
	 * @return
	 */
	final public ExtendedGridBagConstraints setMargins(int intPtop, int intPbottom, int intPleft, int intPright) {
		if (intPtop >= 0 && intPbottom >= 0 && intPleft >= 0 && intPright >= 0) {
			this.insets = new Insets(intPtop, intPleft, intPbottom, intPright);
		} else {
			Tools.errors("bad grid inset value : (", intPtop, ", ", intPbottom, ", ", intPleft, ", ", intPright, ')');
		}
		return this;
	}
}

/*
 * @(#)ExtendedGridBagConstraints.java 4.3.0
 * Copyleft (c) 2010 Arnaud BeLO.
 */
