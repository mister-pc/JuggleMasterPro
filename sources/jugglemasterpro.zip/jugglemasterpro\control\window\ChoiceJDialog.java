/*
 * @(#)ChoiceJDialog.java 4.3.0
 * Copyleft (c) 2010 Arnaud BeLO.
 */

package jugglemasterpro.control.window;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import jugglemasterpro.control.ControlJFrame;
import jugglemasterpro.control.util.ExtendedGridBagConstraints;
import jugglemasterpro.control.util.ExtendedJButton;
import jugglemasterpro.control.util.ExtendedJLabel;
import jugglemasterpro.util.Constants;
import jugglemasterpro.util.Strings;
import jugglemasterpro.util.Tools;

// import static java.lang.Math.*;

/**
 * Description
 * 
 * @version 4.3.0
 * @author Arnaud BeLO.
 */
final public class ChoiceJDialog extends JDialog implements ActionListener {

	public ChoiceJDialog(	ControlJFrame objPcontrolJFrame,
							String strPdialogTitle,
							int intPiconFileType,
							String strPfirstJButton,
							int intPfirstButtonToolTipIndex,
							int intPfirstIconFileType,
							int intPfirstRollOverIconFileType,
							String strPsecondJButton,
							int intPsecondButtonToolTipIndex,
							int intPsecondIconFileType,
							int intPsecondRollOverIconFileType,
							boolean bolPfirstJButtonFocused,
							String... strPlabelA) {
		this(	objPcontrolJFrame,
				objPcontrolJFrame,
				strPdialogTitle,
				intPiconFileType,
				strPfirstJButton,
				intPfirstButtonToolTipIndex,
				intPfirstIconFileType,
				intPfirstRollOverIconFileType,
				strPsecondJButton,
				intPsecondButtonToolTipIndex,
				intPsecondIconFileType,
				intPsecondRollOverIconFileType,
				bolPfirstJButtonFocused,
				strPlabelA);
	}

	public ChoiceJDialog(	ControlJFrame objPcontrolJFrame,
							String strPdialogTitle,
							int intPiconFileType,
							String strPfirstJButton,
							int intPfirstButtonToolTipIndex,
							int intPfirstIconFileType,
							int intPfirstRollOverIconFileType,
							String strPsecondJButton,
							int intPsecondButtonToolTipIndex,
							int intPsecondIconFileType,
							int intPsecondRollOverIconFileType,
							String... strPlabelA) {
		this(	objPcontrolJFrame,
				objPcontrolJFrame,
				strPdialogTitle,
				intPiconFileType,
				strPfirstJButton,
				intPfirstButtonToolTipIndex,
				intPfirstIconFileType,
				intPfirstRollOverIconFileType,
				strPsecondJButton,
				intPsecondButtonToolTipIndex,
				intPsecondIconFileType,
				intPsecondRollOverIconFileType,
				true,
				strPlabelA);
	}

	public ChoiceJDialog(	ControlJFrame objPcontrolJFrame,
							String strPdialogTitle,
							int intPiconFileType,
							String strPfirstJButton,
							int intPfirstIconFileType,
							int intPfirstRollOverIconFileType,
							String strPsecondJButton,
							int intPsecondIconFileType,
							int intPsecondRollOverIconFileType,
							boolean bolPfirstJButtonFocused,
							String... strPlabelA) {
		this(	objPcontrolJFrame,
				objPcontrolJFrame,
				strPdialogTitle,
				intPiconFileType,
				strPfirstJButton,
				Constants.bytS_UNCLASS_NO_VALUE,
				intPfirstIconFileType,
				intPfirstRollOverIconFileType,
				strPsecondJButton,
				Constants.bytS_UNCLASS_NO_VALUE,
				intPsecondIconFileType,
				intPsecondRollOverIconFileType,
				bolPfirstJButtonFocused,
				strPlabelA);
	}

	public ChoiceJDialog(	ControlJFrame objPcontrolJFrame,
							String strPdialogTitle,
							int intPiconFileType,
							String strPfirstJButton,
							int intPfirstIconFileType,
							int intPfirstRollOverIconFileType,
							String strPsecondJButton,
							int intPsecondIconFileType,
							int intPsecondRollOverIconFileType,
							String... strPlabelA) {
		this(	objPcontrolJFrame,
				objPcontrolJFrame,
				strPdialogTitle,
				intPiconFileType,
				strPfirstJButton,
				Constants.bytS_UNCLASS_NO_VALUE,
				intPfirstIconFileType,
				intPfirstRollOverIconFileType,
				strPsecondJButton,
				Constants.bytS_UNCLASS_NO_VALUE,
				intPsecondIconFileType,
				intPsecondRollOverIconFileType,
				true,
				strPlabelA);
	}

	public ChoiceJDialog(	ControlJFrame objPcontrolJFrame,
							String strPdialogTitle,
							int intPiconFileType,
							String strPfirstJButton,
							int intPfirstIconFileType,
							String strPsecondJButton,
							int intPsecondIconFileType,
							boolean bolPfirstJButtonFocused,
							String... strPlabelA) {
		this(	objPcontrolJFrame,
				objPcontrolJFrame,
				strPdialogTitle,
				intPiconFileType,
				strPfirstJButton,
				Constants.bytS_UNCLASS_NO_VALUE,
				intPfirstIconFileType,
				intPfirstIconFileType,
				strPsecondJButton,
				Constants.bytS_UNCLASS_NO_VALUE,
				intPsecondIconFileType,
				intPsecondIconFileType,
				bolPfirstJButtonFocused,
				strPlabelA);
	}

	/**
	 * Constructs
	 * 
	 * @param objPcontrolJFrame
	 * @param strPdialogTitle
	 * @param bytPiconFileType
	 * @param strPfirstJButton
	 * @param bytPfirstIconFileType
	 * @param strPsecondJButton
	 * @param bytPsecondIconFileType
	 * @param strPlabelA
	 */
	public ChoiceJDialog(	ControlJFrame objPcontrolJFrame,
							String strPdialogTitle,
							int intPiconFileType,
							String strPfirstJButton,
							int intPfirstIconFileType,
							String strPsecondJButton,
							int intPsecondIconFileType,
							String... strPlabelA) {
		this(	objPcontrolJFrame,
				objPcontrolJFrame,
				strPdialogTitle,
				intPiconFileType,
				strPfirstJButton,
				Constants.bytS_UNCLASS_NO_VALUE,
				intPfirstIconFileType,
				intPfirstIconFileType,
				strPsecondJButton,
				Constants.bytS_UNCLASS_NO_VALUE,
				intPsecondIconFileType,
				intPsecondIconFileType,
				true,
				strPlabelA);
	}

	public ChoiceJDialog(	ControlJFrame objPcontrolJFrame,
							Window objPparentWindow,
							String strPdialogTitle,
							int intPiconFileType,
							String strPfirstJButton,
							int intPfirstButtonToolTipIndex,
							int intPfirstIconFileType,
							int intPfirstRollOverIconFileType,
							String strPsecondJButton,
							int intPsecondButtonToolTipIndex,
							int intPsecondIconFileType,
							int intPsecondRollOverIconFileType,
							boolean bolPfirstJButtonFocused,
							String... strPlabelA) {
		super(objPcontrolJFrame, Strings.doConcat(strPdialogTitle, Strings.strS_ELLIPSIS), true);
		this.objGcontrolJFrame = objPcontrolJFrame;
		final Image imgL = this.objGcontrolJFrame.getJuggleMasterPro().getImage(intPiconFileType, 0);
		this.setIconImage(imgL != null ? imgL : this.objGcontrolJFrame.getJuggleMasterPro().getFrame().imgGjmp);
		this.setLayout(new GridBagLayout());
		final ExtendedGridBagConstraints objLextendedGridBagConstraints =
																			new ExtendedGridBagConstraints(	0,
																											GridBagConstraints.RELATIVE,
																											1,
																											1,
																											GridBagConstraints.CENTER,
																											10,
																											0,
																											10,
																											10);
		for (final String strLlabel : strPlabelA) {
			this.add(new ExtendedJLabel(objPcontrolJFrame, strLlabel), objLextendedGridBagConstraints);
		}
		final JPanel objLjbuttonsJpanel = new JPanel(new GridLayout(1, 2, 15, 0));
		objLjbuttonsJpanel.setOpaque(true);
		this.objGfirstJButton = new ExtendedJButton(this.objGcontrolJFrame, strPfirstJButton);
		this.objGfirstJButton.setMargin(new Insets(5, 25, 5, 25));
		ImageIcon icoL = this.objGcontrolJFrame.getJuggleMasterPro().getImageIcon(intPfirstIconFileType, 2);
		ImageIcon icoLrollOver =
									intPfirstRollOverIconFileType == intPfirstIconFileType
																							? icoL
																							: this.objGcontrolJFrame.getJuggleMasterPro()
																													.getImageIcon(	intPfirstRollOverIconFileType,
																																	2);
		Tools.setIcons(this.objGfirstJButton, icoL, icoLrollOver);
		this.objGfirstJButton.addActionListener(this);
		this.objGfirstJButton.setToolTipText(this.objGcontrolJFrame.getLanguageString(intPfirstButtonToolTipIndex));
		objLjbuttonsJpanel.add(this.objGfirstJButton);

		this.objGsecondJButton = new ExtendedJButton(this.objGcontrolJFrame, strPsecondJButton);
		this.objGsecondJButton.setMargin(new Insets(5, 25, 5, 25));
		icoL = this.objGcontrolJFrame.getJuggleMasterPro().getImageIcon(intPsecondIconFileType, 2);
		icoLrollOver =
						intPsecondRollOverIconFileType == intPsecondIconFileType
																				? icoL
																				: this.objGcontrolJFrame.getJuggleMasterPro()
																										.getImageIcon(	intPsecondRollOverIconFileType,
																														2);
		Tools.setIcons(this.objGsecondJButton, icoL, icoLrollOver);
		this.objGsecondJButton.addActionListener(this);
		this.objGfirstJButton.setToolTipText(this.objGcontrolJFrame.getLanguageString(intPsecondButtonToolTipIndex));
		objLjbuttonsJpanel.add(this.objGsecondJButton);

		objLextendedGridBagConstraints.setMargins(15, 10, 10, 10);
		this.add(objLjbuttonsJpanel, objLextendedGridBagConstraints);
		this.validate();
		this.pack();
		this.objGcontrolJFrame.setWindowBounds(this, objPparentWindow != objPcontrolJFrame ? objPparentWindow : null);
		this.setResizable(false);
		if (bolPfirstJButtonFocused) {
			this.objGfirstJButton.requestFocusInWindow();
		} else {
			this.objGsecondJButton.requestFocusInWindow();
		}
		this.addWindowListener(new JDialogWindowListener(this.objGcontrolJFrame, this, true));
	}

	public ChoiceJDialog(	ControlJFrame objPcontrolJFrame,
							Window objPparentWindow,
							String strPdialogTitle,
							int intPiconFileType,
							String strPfirstJButton,
							int intPfirstButtonToolTipIndex,
							int intPfirstIconFileType,
							int intPfirstRollOverIconFileType,
							String strPsecondJButton,
							int intPsecondButtonToolTipIndex,
							int intPsecondIconFileType,
							int intPsecondRollOverIconFileType,
							String... strPlabelA) {
		this(	objPcontrolJFrame,
				objPparentWindow,
				strPdialogTitle,
				intPiconFileType,
				strPfirstJButton,
				intPfirstButtonToolTipIndex,
				intPfirstIconFileType,
				intPfirstRollOverIconFileType,
				strPsecondJButton,
				intPsecondButtonToolTipIndex,
				intPsecondIconFileType,
				intPsecondRollOverIconFileType,
				true,
				strPlabelA);
	}

	/**
	 * @param objGcontrolJFrame2
	 * @param preferencesJDialog
	 * @param languageString
	 * @param intsFileIconAlert
	 * @param languageString2
	 * @param intsFileIconOkBw
	 * @param intsFileIconOk
	 * @param languageString3
	 * @param intsFileIconCancelBw
	 * @param intsFileIconCancel
	 * @param b
	 * @param languageString4
	 */
	public ChoiceJDialog(	ControlJFrame objPcontrolJFrame,
							Window objPparentWindow,
							String strPdialogTitle,
							int intPiconFileType,
							String strPfirstJButton,
							int intPfirstIconFileType,
							int intPfirstRollOverIconFileType,
							String strPsecondJButton,
							int intPsecondIconFileType,
							int intPsecondRollOverIconFileType,
							boolean bolPfirstJButtonFocused,
							String strPlabelA) {
		this(	objPcontrolJFrame,
				objPparentWindow,
				strPdialogTitle,
				intPiconFileType,
				strPfirstJButton,
				Constants.bytS_UNCLASS_NO_VALUE,
				intPfirstIconFileType,
				intPfirstRollOverIconFileType,
				strPsecondJButton,
				Constants.bytS_UNCLASS_NO_VALUE,
				intPsecondIconFileType,
				intPsecondRollOverIconFileType,
				bolPfirstJButtonFocused,
				strPlabelA);
	}

	public ChoiceJDialog(	ControlJFrame objPcontrolJFrame,
							Window objPparentWindow,
							String strPdialogTitle,
							int intPiconFileType,
							String strPfirstJButton,
							int intPfirstIconFileType,
							int intPfirstRollOverIconFileType,
							String strPsecondJButton,
							int intPsecondIconFileType,
							int intPsecondRollOverIconFileType,
							String... strPlabelA) {
		this(	objPcontrolJFrame,
				objPparentWindow,
				strPdialogTitle,
				intPiconFileType,
				strPfirstJButton,
				Constants.bytS_UNCLASS_NO_VALUE,
				intPfirstIconFileType,
				intPfirstRollOverIconFileType,
				strPsecondJButton,
				Constants.bytS_UNCLASS_NO_VALUE,
				intPsecondIconFileType,
				intPsecondRollOverIconFileType,
				true,
				strPlabelA);
	}

	public ChoiceJDialog(	ControlJFrame objPcontrolJFrame,
							Window objPparentWindow,
							String strPdialogTitle,
							int intPiconFileType,
							String strPfirstJButton,
							int intPfirstIconFileType,
							String strPsecondJButton,
							int intPsecondIconFileType,
							boolean bolPfirstJButtonFocused,
							String... strPlabelA) {
		this(	objPcontrolJFrame,
				objPparentWindow,
				strPdialogTitle,
				intPiconFileType,
				strPfirstJButton,
				Constants.bytS_UNCLASS_NO_VALUE,
				intPfirstIconFileType,
				intPfirstIconFileType,
				strPsecondJButton,
				Constants.bytS_UNCLASS_NO_VALUE,
				intPsecondIconFileType,
				intPsecondIconFileType,
				bolPfirstJButtonFocused,
				strPlabelA);
	}

	public ChoiceJDialog(	ControlJFrame objPcontrolJFrame,
							Window objPparentWindow,
							String strPdialogTitle,
							int intPiconFileType,
							String strPfirstJButton,
							int intPfirstIconFileType,
							String strPsecondJButton,
							int intPsecondIconFileType,
							String... strPlabelA) {
		this(	objPcontrolJFrame,
				objPparentWindow,
				strPdialogTitle,
				intPiconFileType,
				strPfirstJButton,
				Constants.bytS_UNCLASS_NO_VALUE,
				intPfirstIconFileType,
				intPfirstIconFileType,
				strPsecondJButton,
				Constants.bytS_UNCLASS_NO_VALUE,
				intPsecondIconFileType,
				intPsecondIconFileType,
				true,
				strPlabelA);
	}

	/**
	 * Method description
	 * 
	 * @see
	 * @param objPactionEvent
	 */
	@Override final public void actionPerformed(ActionEvent objPactionEvent) {

		Tools.debug("ChoiceJDialog.actionPerformed()");
		final JButton objLactionedJButton = ((JButton) (objPactionEvent.getSource()));
		this.bytGchoice =
							(objLactionedJButton == this.objGfirstJButton
																			? ChoiceJDialog.bytS_FIRST_CHOICE
																			: objLactionedJButton == this.objGsecondJButton
																															? ChoiceJDialog.bytS_SECOND_CHOICE
																															: Constants.bytS_UNCLASS_NO_VALUE);
		this.setVisible(false);
	}

	public byte					bytGchoice			= Constants.bytS_UNCLASS_NO_VALUE;

	final private ControlJFrame	objGcontrolJFrame;

	ExtendedJButton				objGfirstJButton;

	ExtendedJButton				objGsecondJButton;

	final public static byte	bytS_FIRST_CHOICE	= 1;

	final public static byte	bytS_SECOND_CHOICE	= 2;

	final private static long	serialVersionUID	= Constants.lngS_ENGINE_VERSION_NUMBER;
}

/*
 * @(#)ChoiceJDialog.java 4.3.0
 * Copyleft (c) 2010 Arnaud BeLO.
 */
