/*
 * @(#)ConsoleObject.java 4.3.0
 * Copyleft (c) 2010 Arnaud BeLO.
 */

package jugglemasterpro.pattern.util;




import jugglemasterpro.user.Language;
import jugglemasterpro.util.Constants;
import jugglemasterpro.util.Strings;




/**
 * Description
 * 
 * @version 4.3.0
 * @author Arnaud BeLO.
 */
final public class ConsoleObject {

	final public static byte	bytS_ERROR				= 1;

	final public static byte	bytS_PATTERNS_IMPORT	= 3;

	final public static byte	bytS_PATTERNS_LOAD		= 2;

	final public static byte	bytS_SITESWAPS_IMPORT	= 4;
	final public static byte	bytS_STYLES_IMPORT		= 5;
	final public static byte	bytS_WARNING			= 0;
	final private static long	serialVersionUID		= Constants.lngS_ENGINE_VERSION_NUMBER;




	private final boolean		bolGlocal;
	private final int			intGfileLineCursorIndex;
	private final int			intGfileLineIndex;
	private final int			intGlanguageIndex;
	private final String		strGfileLine;




	/**
	 * Constructs
	 * 
	 * @param intPlanguageIndex
	 * @param bytPtype
	 * @param intPfileLineIndex
	 * @param intPfileLineCursorIndex
	 * @param bolPlocal
	 * @param strPfileLine
	 */
	public ConsoleObject(int intPlanguageIndex, int intPfileLineIndex, int intPfileLineCursorIndex, boolean bolPlocal, String strPfileLine) {
		this.intGlanguageIndex = intPlanguageIndex;
		this.intGfileLineIndex = intPfileLineIndex;
		this.intGfileLineCursorIndex = intPfileLineCursorIndex;
		this.bolGlocal = bolPlocal;
		this.strGfileLine = strPfileLine;
	}




	/**
	 * Method description
	 * 
	 * @see
	 * @return Index of the file line which encountered the problem
	 */
	final public int getFileLineIndex() {
		return this.intGfileLineIndex;
	}




	/**
	 * Method description
	 * 
	 * @see
	 * @param bolPfatal
	 *            If the problem encountered is an error or just a warning
	 * @param bolPlocal
	 * @param objPlanguage
	 * @return
	 */
	final public String toString(boolean bolPfatal, boolean bolPlocal, Language objPlanguage) {
		if (bolPlocal && !this.bolGlocal) {
			return Strings.strS_EMPTY;
		}

		// Line index & line string :
		final String strLheader =
										Strings.doConcat(	objPlanguage.getPropertyValueString(Language.intS_LABEL_LINE_INDEX),
																' ',
																this.intGfileLineIndex,
																" : ");

		// Line cursor :
		final int intLheaderStringLength = strLheader.length();
		final StringBuilder objLlineCursorStringBuilder = new StringBuilder(intLheaderStringLength + this.intGfileLineCursorIndex + 4);

		if (this.intGfileLineCursorIndex >= 0) {
			for (int intLcursorIndex = 0; intLcursorIndex < intLheaderStringLength + this.intGfileLineCursorIndex; ++intLcursorIndex) {
				objLlineCursorStringBuilder.append('-');
			}

			objLlineCursorStringBuilder.append(Strings.doConcat('^', Strings.strS_LINE_SEPARATOR));
		}

		// Get error string :
		return Strings.doConcat(	Strings.strS_LINE_SEPARATOR,
										Strings.strS_LINE_SEPARATOR,
										strLheader,
										this.strGfileLine,
										Strings.strS_LINE_SEPARATOR,
										objLlineCursorStringBuilder,
										objPlanguage.getPropertyValueString(bolPfatal ? Language.intS_LABEL_ERROR
																							: Language.intS_LABEL_WARNING),
										" : ",
										objPlanguage.getPropertyValueString(this.intGlanguageIndex),
										'.',
										Strings.strS_LINE_SEPARATOR);
	}
}

/*
 * @(#)ConsoleObject.java 4.3.0
 * Copyleft (c) 2010 Arnaud BeLO.
 */
