package jugglemasterpro.pattern.util;

import java.util.ArrayList;
import javax.swing.ImageIcon;
import jugglemasterpro.pattern.BallsColors;
import jugglemasterpro.pattern.Pattern;
import jugglemasterpro.pattern.PatternsManager;
import jugglemasterpro.pattern.Siteswap;
import jugglemasterpro.user.Language;
import jugglemasterpro.user.Preferences;
import jugglemasterpro.util.Constants;
import jugglemasterpro.util.Strings;
import jugglemasterpro.util.Tools;

final public class PatternsFileParser {

	final private static long			serialVersionUID	= Constants.lngS_ENGINE_VERSION_NUMBER;

	private final PatternsManager	objGpatternsManager;

	/**
	 * Method description
	 * 
	 * @see
	 * @param objPpatternsBufferedReader
	 * @param strPtitle
	 * @param bolPnewLists
	 * @param bolPsiteswaps
	 * @param bolPstyles
	 * @param strPpatternName
	 * @param intPstartPatternOccurrence
	 */
	public PatternsFileParser(PatternsManager objPpatternsManager) {
		this.objGpatternsManager = objPpatternsManager;
	}

	/**
	 * Method description
	 * 
	 * @see
	 * @param strPcolors
	 * @return
	 */
	final private BallsColors doParseBallsColors(String strPballsColors) {

		final BallsColors objLballColors = new BallsColors(strPballsColors);
		if (objLballColors.getState() != Boolean.FALSE) {
			this.objGpatternsManager.strGglobalAA[Constants.bytS_STRING_LOCAL_COLORS][Constants.bytS_UNCLASS_INITIAL] =
																																				objLballColors.getBallsColorsString();
			this.objGpatternsManager.bolGstringIsFileDefinedA[Constants.bytS_STRING_LOCAL_COLORS] =
																												this.objGpatternsManager.bolGstringIsFileDefinedA[Constants.bytS_STRING_LOCAL_REVERSE_COLORS] =
																																																							true;
		}
		return (objLballColors);
	}

	final public void doParsePatternsFile(	PatternsBufferedReader objPpatternsBufferedReader,
											ImageIcon imgP,
											boolean bolPnewLists,
											boolean bolPsiteswaps,
											boolean bolPstyles,
											String strPpatternName,
											boolean bolPonlyThisPattern,
											int intPstartPatternOccurrence) {

		/* Initializations : */
		final PatternsFileStyleParser objLpatternsFileStyleParser =
																	new PatternsFileStyleParser(this.objGpatternsManager,
																								objPpatternsBufferedReader);
		final PatternsFileParameterParser objLpatternsFileParameterParser = new PatternsFileParameterParser(this.objGpatternsManager);
		boolean bolLsiteswapWithoutStyleErrorEnabled = bolPsiteswaps && bolPstyles;
		boolean bolLpatternFound = false;
		int intLobjectsNumber = bolPnewLists ? 0 : this.objGpatternsManager.objGobjectA.length;
		final int intLstartPatternOccurrence = Math.max(intPstartPatternOccurrence + 1, 1);
		int intLcurrentPatternOccurrence = intLstartPatternOccurrence;
		final ArrayList<Object> objLobjectAL = new ArrayList<Object>(128);
		final ArrayList<Integer> objLshortcutIndexIntegerAL = new ArrayList<Integer>(8);

		this.objGpatternsManager.strGfileNameAL.add(objPpatternsBufferedReader.getReferenceString());
		this.objGpatternsManager.strGfileTitleAL.add(objPpatternsBufferedReader.getTitleString());
		this.objGpatternsManager.objGfileImageIconAL.add(imgP);
		this.objGpatternsManager.bolGfileSiteswapsBooleanAL.add(bolPsiteswaps);
		this.objGpatternsManager.bolGfileStylesBooleanAL.add(bolPstyles);

		if (bolPnewLists) {
			this.objGpatternsManager.strGstyleAL = new ArrayList<String>(bolPstyles ? 64 : 1);
			this.objGpatternsManager.strGstyleAL.add(Constants.strS_STRING_LOCAL_STYLE_DEFAULT);
		} else {
			this.objGpatternsManager.initInitialValues(false, objPpatternsBufferedReader.hasJMFormat());
			this.objGpatternsManager.bolGglobalValueAA[Constants.bytS_BOOLEAN_LOCAL_ERRORS][Constants.bytS_UNCLASS_INITIAL] =
																																				this.objGpatternsManager.bolGglobalValueAA[Constants.bytS_BOOLEAN_LOCAL_WARNINGS][Constants.bytS_UNCLASS_INITIAL] =
																																																																						true;

			this.objGpatternsManager.objGwrongStyleAL = new ArrayList<String>();
			this.objGpatternsManager.objGfatalJuggleErrorAL = new ArrayList<ConsoleObject>();
			this.objGpatternsManager.objGwarningJuggleErrorAL = new ArrayList<ConsoleObject>();
			this.objGpatternsManager.intGglobalFatalErrorsNumber =
																			this.objGpatternsManager.intGlocalFatalErrorsNumber =
																																		this.objGpatternsManager.intGlocalWarningsNumber =
																																																	this.objGpatternsManager.intGglobalWarningsNumber =
																																																																0;
			if (bolPsiteswaps) {
				this.objGpatternsManager.bytGpatternsManagerType = Constants.bytS_MANAGER_FILES_PATTERNS;
			}
		}

		this.objGpatternsManager.strGglobalAA[Constants.bytS_STRING_LOCAL_STYLE][Constants.bytS_UNCLASS_INITIAL] =
																																			this.objGpatternsManager.strGglobalAA[Constants.bytS_STRING_LOCAL_STYLE][Constants.bytS_UNCLASS_CURRENT] =
																																																																				Constants.strS_STRING_LOCAL_STYLE_DEFAULT;

		// Read the file till founding the pattern(s) :
		while (objPpatternsBufferedReader.doReadNextLine()) {

			if (strPpatternName != null && bolPonlyThisPattern && bolLpatternFound) {
				break;
			}

			// First char analysis :
			final char[] chrLfileLineA = objPpatternsBufferedReader.getLineString().toCharArray();
			String strLdata = Strings.uncomment(objPpatternsBufferedReader.getLineString().substring(1)).trim();

			switch (chrLfileLineA[0]) {

				// Comment line :
				case '/':
					if (bolPsiteswaps) {

						// Add shortcut :
						if (strLdata.startsWith("[") && strLdata.endsWith("]")) {
							strLdata = strLdata.substring(1, strLdata.length() - 1);
							objLshortcutIndexIntegerAL.add(Integer.valueOf(intLobjectsNumber + (bolPnewLists ? 0 : 2)));
						}

						// Add comment :
						objLobjectAL.add(strLdata);
						++intLobjectsNumber;
					}

					break;

				// Colors :
				case '$':
					if (bolPsiteswaps) {
						final BallsColors objLballColors = this.doParseBallsColors(strLdata);

						if (objLballColors.getState() == null) {
							this.objGpatternsManager.doAddToConsole(	Language.intS_WARNING_COLORS_MALFORMED_VALUE,
																			ConsoleObject.bytS_WARNING,
																			objPpatternsBufferedReader,
																			objLballColors.getErrorIndex() + 1);
						} else if (objLballColors.getState() == Boolean.FALSE) {
							this.objGpatternsManager.doAddToConsole(	Language.intS_ERROR_COLORS_UNKNOWN_VALUE,
																			ConsoleObject.bytS_ERROR,
																			objPpatternsBufferedReader,
																			objLballColors.getErrorIndex() + 1);
						}
					}
					break;

				// Height, Level & Dwell :
				case '^':
				case '�':
				case '@':
					if (strLdata.length() == 0) {
						this.objGpatternsManager.doAddToConsole(	Language.intS_ERROR_PARAMETER_MISSING_VALUE,
																		ConsoleObject.bytS_ERROR,
																		objPpatternsBufferedReader,
																		1);
					} else {
						if (!objLpatternsFileParameterParser.deprecatedDoParseShortParameter(chrLfileLineA[0], strLdata)) {
							final int intLerrorType =
														(chrLfileLineA[0] == '^'
																				? Language.intS_ERROR_HEIGHT_UNKNOWN_VALUE
																				: chrLfileLineA[0] == '�'
																											? Language.intS_ERROR_SKILL_UNKNOWN_VALUE
																											: Language.intS_ERROR_DWELL_UNKNOWN_VALUE);
							final int intLerrorIndex = objPpatternsBufferedReader.getLineString().indexOf(strLdata, 1);
							this.objGpatternsManager.doAddToConsole(	intLerrorType,
																			ConsoleObject.bytS_ERROR,
																			objPpatternsBufferedReader,
																			intLerrorIndex);
						}
					}
					break;

				// Parameter:
				case '#':
					final Object[] objLstyleParameterObjectA =
																objLpatternsFileParameterParser.doParseParameter(	objPpatternsBufferedReader,
																													bolPnewLists,
																													bolPstyles,
																													bolPsiteswaps);
					if (objLstyleParameterObjectA != null) {
						if (bolPstyles) {
							if (objLpatternsFileStyleParser.doParseStyle(	(String) objLstyleParameterObjectA[0],
																			((Integer) objLstyleParameterObjectA[1]).intValue())) {
								this.objGpatternsManager.bolGstyleFound = true;
								bolLsiteswapWithoutStyleErrorEnabled = false;
							}
						} else {
							objPpatternsBufferedReader.doSkipStyleDefinition();
						}
					}
					break;

				// Style :
				case '%':

					if (bolPstyles) {
						if (strLdata.length() == 0) {
							this.objGpatternsManager.doAddToConsole(	Language.intS_ERROR_NO_STYLE_NAME,
																			ConsoleObject.bytS_ERROR,
																			objPpatternsBufferedReader,
																			Constants.bytS_UNCLASS_NO_VALUE);
							objPpatternsBufferedReader.doSkipStyleDefinition();
						} else {
							int intLstyleNameIndex = 1;
							while ((intLstyleNameIndex < chrLfileLineA.length) && (chrLfileLineA[intLstyleNameIndex] == ' ')) {
								++intLstyleNameIndex;
							}

							if (objLpatternsFileStyleParser.doParseStyle(strLdata, intLstyleNameIndex)) {
								this.objGpatternsManager.bolGstyleFound = true;
								bolLsiteswapWithoutStyleErrorEnabled = false;
							}
						}
					} else {
						objPpatternsBufferedReader.doSkipStyleDefinition();
					}
					break;

				// Style definition with no style name associated :
				case '{':
					if (bolPstyles /* && !bolLstyleDefinitionMissingNameError */) {
						this.objGpatternsManager.doAddToConsole(	Language.intS_ERROR_STYLE_DEFINITION_MISSING_NAME,
																		ConsoleObject.bytS_ERROR,
																		objPpatternsBufferedReader,
																		0);
					}
					objPpatternsBufferedReader.doSkipStyleDefinition();
					break;

				// Siteswap & pattern name :
				default:
					chrLfileLineA[0] = Character.toLowerCase(chrLfileLineA[0]);
					if (((chrLfileLineA[0] >= '0') && (chrLfileLineA[0] <= '9')) || ((chrLfileLineA[0] >= 'a') && (chrLfileLineA[0] <= 'z'))
						|| (chrLfileLineA[0] == '(') || (chrLfileLineA[0] == '"') || (chrLfileLineA[0] == '\'') || (chrLfileLineA[0] == '[')) {
						if (bolPsiteswaps
							&& (bolPstyles || this.objGpatternsManager.bolGglobalValueAA[Constants.bytS_BOOLEAN_LOCAL_EDITION][Constants.bytS_UNCLASS_INITIAL])) {

							final int intLreturnedPatternOccurrence =
																		this.doParseSiteswap(	objLobjectAL,
																								objPpatternsBufferedReader,
																								strPpatternName,
																								bolPonlyThisPattern,
																								intLstartPatternOccurrence,
																								intLcurrentPatternOccurrence,
																								bolLsiteswapWithoutStyleErrorEnabled,
																								bolPstyles);
							if (intLreturnedPatternOccurrence >= 0) {
								bolLpatternFound = !bolPonlyThisPattern || intLreturnedPatternOccurrence == 1;
								bolLsiteswapWithoutStyleErrorEnabled = false;
								++intLobjectsNumber;
								if (strPpatternName != null && intLreturnedPatternOccurrence > 0) {
									intLcurrentPatternOccurrence = intLreturnedPatternOccurrence;
								}
							}
						}
					} else {
						this.objGpatternsManager.doAddToConsole(	Language.intS_ERROR_NO_SENSE,
																		ConsoleObject.bytS_ERROR,
																		objPpatternsBufferedReader,
																		objPpatternsBufferedReader.getLineString().indexOf(chrLfileLineA[0]));
					}
					break;
			}
		}

		this.objGpatternsManager.initCurrentValues();
		if (bolPsiteswaps) {
			if (!bolLpatternFound) {
				if (bolPnewLists) {
					this.objGpatternsManager.doCreateNoPatternManager(this.objGpatternsManager.strGfileNameAL.get(0),
																			this.objGpatternsManager.strGfileTitleAL.get(0),
																			this.objGpatternsManager.objGfileImageIconAL.get(0),
																			this.objGpatternsManager.bolGfileSiteswapsBooleanAL.get(0),
																			this.objGpatternsManager.bolGfileStylesBooleanAL.get(0),
																			objLobjectAL,
																			this.objGpatternsManager.bolGstyleFound
																															? this.objGpatternsManager.strGglobalAA[Constants.bytS_STRING_LOCAL_STYLE][Constants.bytS_UNCLASS_INITIAL]
																															: null);
				}
			} else {

				// Create (new) object list :
				if (bolPnewLists) {
					this.objGpatternsManager.objGobjectA = objLobjectAL.toArray();
				} else {
					objLobjectAL.add(0, Strings.strS_SPACE);
					objLobjectAL.add(	1,
										Strings.doConcat(	"[ ",
																(bolPsiteswaps && bolPstyles)
																								? Language.strS_TOKEN_A[Language.bytS_TOKEN_PATTERNS_IMPORTED_FROM]
																								: Language.strS_TOKEN_A[Language.bytS_TOKEN_SITESWAPS_IMPORTED_FROM],
																" : ",
																objPpatternsBufferedReader.getReferenceString(),
																" ]"));
					objLshortcutIndexIntegerAL.add(0, Integer.valueOf(this.objGpatternsManager.objGobjectA.length + 1));

					final Object[] objLpreviousObjectA = new Object[this.objGpatternsManager.objGobjectA.length];
					final Object[] objLimportedObjectA = objLobjectAL.toArray();
					System.arraycopy(	this.objGpatternsManager.objGobjectA,
										0,
										objLpreviousObjectA,
										0,
										this.objGpatternsManager.objGobjectA.length);
					this.objGpatternsManager.objGobjectA = new Object[objLpreviousObjectA.length + objLimportedObjectA.length];
					System.arraycopy(objLpreviousObjectA, 0, this.objGpatternsManager.objGobjectA, 0, objLpreviousObjectA.length);
					System.arraycopy(	objLimportedObjectA,
										0,
										this.objGpatternsManager.objGobjectA,
										objLpreviousObjectA.length,
										objLimportedObjectA.length);
				}

				// Shortcut list serialization :
				if (bolPsiteswaps) {
					final int intLnewShortcutsNumber = objLshortcutIndexIntegerAL.size();

					if (bolPnewLists || (this.objGpatternsManager.intGshortcutIndexA == null)) {
						this.objGpatternsManager.intGshortcutIndexA = null;

						if (intLnewShortcutsNumber > 0) {
							this.objGpatternsManager.intGshortcutIndexA = new int[intLnewShortcutsNumber];

							for (int intLarrayListIndex = 0; intLarrayListIndex < intLnewShortcutsNumber; ++intLarrayListIndex) {
								this.objGpatternsManager.intGshortcutIndexA[intLarrayListIndex] =
																										objLshortcutIndexIntegerAL	.get(intLarrayListIndex)
																																	.intValue();
							}
						}
					} else {
						if (intLnewShortcutsNumber > 0) {
							final int[] intLnewShortcutIndexA =
																new int[this.objGpatternsManager.intGshortcutIndexA.length
																		+ intLnewShortcutsNumber];

							System.arraycopy(	this.objGpatternsManager.intGshortcutIndexA,
												0,
												intLnewShortcutIndexA,
												0,
												this.objGpatternsManager.intGshortcutIndexA.length);

							for (int intLnewShortcutIndex = 0; intLnewShortcutIndex < intLnewShortcutsNumber; ++intLnewShortcutIndex) {
								intLnewShortcutIndexA[this.objGpatternsManager.intGshortcutIndexA.length + intLnewShortcutIndex] =
																																			objLshortcutIndexIntegerAL	.get(intLnewShortcutIndex)
																																										.intValue();
							}

							this.objGpatternsManager.intGshortcutIndexA = intLnewShortcutIndexA;
						}
					}

					// Suppress multiple occurrences of shortcuts by appending space(s) to the second one :
					if (this.objGpatternsManager.intGshortcutIndexA != null) {
						for (int intLshortcutToCompareIndex = 0; intLshortcutToCompareIndex < this.objGpatternsManager.intGshortcutIndexA.length; ++intLshortcutToCompareIndex) {
							for (int intLcomparedShortcutIndex = 0; intLcomparedShortcutIndex < intLshortcutToCompareIndex; ++intLcomparedShortcutIndex) {
								if (((String) this.objGpatternsManager.objGobjectA[this.objGpatternsManager.intGshortcutIndexA[intLshortcutToCompareIndex]]).equals(this.objGpatternsManager.objGobjectA[this.objGpatternsManager.intGshortcutIndexA[intLcomparedShortcutIndex]])) {
									this.objGpatternsManager.objGobjectA[this.objGpatternsManager.intGshortcutIndexA[intLshortcutToCompareIndex]] =
																																								Strings.doConcat(	this.objGpatternsManager.objGobjectA[this.objGpatternsManager.intGshortcutIndexA[intLshortcutToCompareIndex]],
																																														Strings.strS_SPACE);
									intLcomparedShortcutIndex = -1;
								}
							}
						}
					}
				}
			}
		}
	}

	/**
	 * Method description
	 * 
	 * @see
	 * @param objPobjectAL
	 * @param objPpatternsBufferedReader
	 * @param strPpatternName
	 * @param bolPnoSiteswapStyleErrorEnabled
	 * @param bolPstyles
	 * @return
	 */
	final private int doParseSiteswap(	ArrayList<Object> objPobjectAL,
										PatternsBufferedReader objPpatternsBufferedReader,
										String strPpatternName,
										boolean bolPonlyThisPattern,
										int intPstartPatternOccurrence,
										int intPcurrentPatternOccurrence,
										boolean bolPnoSiteswapStyleErrorEnabled,
										boolean bolPstyles) {

		final String strLuncommentUntabFileLine = Strings.uncommentUntab(objPpatternsBufferedReader.getLineString());
		String strLsiteswap = null, strLpatternName = null;
		final boolean bolLquotes = (strLuncommentUntabFileLine.charAt(0) == '"');
		int intLsiteswapSpaceIndex = strLuncommentUntabFileLine.indexOf(' ');

		if (intLsiteswapSpaceIndex == -1) {
			intLsiteswapSpaceIndex = strLuncommentUntabFileLine.length();
		}

		int intLsiteswapEndIndex = (bolLquotes ? strLuncommentUntabFileLine.indexOf('"', 1) : intLsiteswapSpaceIndex);

		if (intLsiteswapEndIndex == -1) {
			intLsiteswapEndIndex = strLuncommentUntabFileLine.length();
		}

		try {
			strLsiteswap = strLuncommentUntabFileLine.substring(bolLquotes ? 1 : 0, intLsiteswapEndIndex);
			strLpatternName = strLuncommentUntabFileLine.substring(intLsiteswapEndIndex + (bolLquotes ? 1 : 0)).trim();
		} catch (final Throwable objPthrowable) {
			// In case of a corrupted (or binary) file :
			Tools.errors("Error while parsing pattern file");
			return Constants.bytS_UNCLASS_NO_VALUE;
		}

		if (strLpatternName.equals(Strings.strS_EMPTY)) {
			strLpatternName = strLsiteswap.trim();
		}

		// Testing pattern name :
		if (bolPonlyThisPattern && strPpatternName != null
			&& !Strings.getUpperCaseString(strPpatternName).equals(Strings.getUpperCaseString(strLpatternName))) {
			return Constants.bytS_UNCLASS_NO_VALUE;
		}

		// Analyzing siteswap :
		final Siteswap objLsiteswap = new Siteswap(strLsiteswap);
		final int intLsiteswapErrorIndex =
											objLsiteswap.intGerrorCursorIndex != Constants.bytS_UNCLASS_NO_VALUE
																															? (bolLquotes ? 1 : 0)
																																+ objLsiteswap.intGerrorCursorIndex
																															: Constants.bytS_UNCLASS_NO_VALUE;
		final byte bytLconsoleObjectType =
											Preferences.getGlobalBooleanPreference(Constants.bytS_BOOLEAN_GLOBAL_INVALID_PATTERNS)
																																				? ConsoleObject.bytS_WARNING
																																				: ConsoleObject.bytS_ERROR;
		switch (objLsiteswap.bytGstatus) {
			case Constants.bytS_STATE_SITESWAP_FORBIDDEN_CHAR:
				this.objGpatternsManager.doAddToConsole(	Language.intS_ERROR_SITESWAP_FORBIDDEN_CHAR,
																ConsoleObject.bytS_ERROR,
																objPpatternsBufferedReader,
																intLsiteswapErrorIndex);
				return Constants.bytS_UNCLASS_NO_VALUE;
			case Constants.bytS_STATE_SITESWAP_UNEXPECTED_CHAR:
				this.objGpatternsManager.doAddToConsole(	Language.intS_ERROR_SITESWAP_UNEXPECTED_CHAR,
																bytLconsoleObjectType,
																objPpatternsBufferedReader,
																intLsiteswapErrorIndex);
				break;
			case Constants.bytS_STATE_SITESWAP_ODD_THROW_VALUE:
				this.objGpatternsManager.doAddToConsole(	Language.intS_ERROR_SITESWAP_ODD_THROW_VALUE,
																bytLconsoleObjectType,
																objPpatternsBufferedReader,
																intLsiteswapErrorIndex);
				break;
			case Constants.bytS_STATE_SITESWAP_EMPTY:
				this.objGpatternsManager.doAddToConsole(	Language.intS_WARNING_SITESWAP_EMPTY,
																ConsoleObject.bytS_WARNING,
																objPpatternsBufferedReader,
																intLsiteswapErrorIndex);
				break;
			case Constants.bytS_STATE_SITESWAP_UNPLAYABLE:
				this.objGpatternsManager.doAddToConsole(	Language.intS_ERROR_SITESWAP_UNPLAYABLE_SEQUENCE,
																bytLconsoleObjectType,
																objPpatternsBufferedReader,
																intLsiteswapErrorIndex);
				break;
			case Constants.bytS_STATE_SITESWAP_UNKNOWN_BALLS_NUMBER:
				this.objGpatternsManager.doAddToConsole(	Language.intS_ERROR_SITESWAP_UNKNOWN_BALLS_NUMBER,
																bytLconsoleObjectType,
																objPpatternsBufferedReader,
																intLsiteswapErrorIndex);
				break;
			case Constants.bytS_STATE_SITESWAP_PLAYABLE:
				break;
		}

		if (bolPnoSiteswapStyleErrorEnabled) {
			this.objGpatternsManager.doAddToConsole(	Language.intS_WARNING_SITESWAP_WITHOUT_STYLE,
															ConsoleObject.bytS_WARNING,
															objPpatternsBufferedReader,
															Constants.bytS_UNCLASS_NO_VALUE);
		}

		this.objGpatternsManager.strGglobalAA[Constants.bytS_STRING_LOCAL_PATTERN][Constants.bytS_UNCLASS_INITIAL] =
																																				bolPstyles
																																							? strLpatternName
																																							: strLsiteswap;
		this.objGpatternsManager.strGglobalAA[Constants.bytS_STRING_LOCAL_SITESWAP][Constants.bytS_UNCLASS_INITIAL] =
																																				strLsiteswap;
		this.objGpatternsManager.strGglobalAA[Constants.bytS_STRING_LOCAL_REVERSE_SITESWAP][Constants.bytS_UNCLASS_INITIAL] =
																																						objLsiteswap.getReverseSiteswapString();
		this.objGpatternsManager.strGglobalAA[Constants.bytS_STRING_LOCAL_REVERSE_COLORS][Constants.bytS_UNCLASS_INITIAL] =
																																					objLsiteswap.getReverseColorsString(this.objGpatternsManager.strGglobalAA[Constants.bytS_STRING_LOCAL_COLORS][Constants.bytS_UNCLASS_INITIAL]);
		objPobjectAL.add(new Pattern(	this.objGpatternsManager,
											objLsiteswap.intGballsNumber,
											objLsiteswap.bytGstatus == Constants.bytS_STATE_SITESWAP_PLAYABLE,
											this.objGpatternsManager.bolGglobalValueAA,
											this.objGpatternsManager.bytGglobalValueAA,
											this.objGpatternsManager.strGglobalAA));
		++this.objGpatternsManager.intGpatternsNumber;

		// Return value :
		if (strPpatternName != null
			&& Strings.getUpperCaseString(strLpatternName).equals(Strings.getUpperCaseString(strPpatternName))
			&& intPcurrentPatternOccurrence > 1) {
			this.objGpatternsManager.intGstartObjectIndex = objPobjectAL.size() - 1;
			this.objGpatternsManager.bolGstartObject = false;
			return intPcurrentPatternOccurrence - 1;
		}

		if (this.objGpatternsManager.bolGstartObject
			&& (Tools.isEmpty(strPpatternName) || intPstartPatternOccurrence == intPcurrentPatternOccurrence)) {
			this.objGpatternsManager.intGstartObjectIndex = objPobjectAL.size() - 1;
			this.objGpatternsManager.bolGstartObject = false;
		}
		return 0;
	}

}
