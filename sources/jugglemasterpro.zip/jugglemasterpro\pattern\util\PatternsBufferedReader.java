/*
 * @(#)PatternsBufferedReader.java 4.3.0
 * Copyleft (c) 2010 Arnaud BeLO.
 */

package jugglemasterpro.pattern.util;




import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.URL;
import jugglemasterpro.util.Constants;
import jugglemasterpro.util.Strings;
import jugglemasterpro.util.Tools;




/**
 * Description
 * 
 * @version 4.3.0
 * @author Arnaud BeLO.
 */
public final class PatternsBufferedReader extends BufferedReader {

	/**
	 * Constructs
	 * 
	 * @param objPreader
	 */
	private PatternsBufferedReader(Reader objPreader, boolean bolPjMFormat) {
		super(objPreader);
		this.bolGjMFormat = bolPjMFormat;
		this.strGfileLine = null;
		this.intGfileLineIndex = 0;
		this.bolGskipStyleDefinition = this.bolGskipNextRead = false;
	}

	/**
	 * Method description
	 * 
	 * @see
	 * @return
	 */
	final public boolean doReadNextLine() {

		if (this.bolGskipNextRead) {
			this.bolGskipNextRead = false;
		} else {
			do {
				try {
					this.strGfileLine = Strings.untabTrim(this.readLine());
					++this.intGfileLineIndex;
				} catch (final Throwable objPfirstThrowable) {
					this.strGfileLine = null;
					try {
						this.close();
					} catch (final Throwable objPsecondThrowable) {
						Tools.errors("Error while closing pattern file descriptor");
					}
					return false;
				}
			} while (this.strGfileLine.length() == 0 || this.strGfileLine.charAt(0) == ';' || this.bolGskipStyleDefinition
						&& (this.strGfileLine.charAt(0) == '{' || this.strGfileLine.charAt(0) == '*'));
			this.bolGskipStyleDefinition = false;
		}
		return true;
	}

	/**
	 * Method description
	 * 
	 * @see
	 */
	final public void doSkipNextRead() {
		this.bolGskipNextRead = true;
	}

	/**
	 * Method description
	 * 
	 * @see
	 */
	final public void doSkipStyleDefinition() {
		this.bolGskipStyleDefinition = true;
	}

	/**
	 * Method description
	 * 
	 * @see
	 * @return
	 */
	final public int getLineIndex() {
		return this.intGfileLineIndex;
	}

	/**
	 * Method description
	 * 
	 * @see
	 * @return
	 */
	final public String getLineString() {
		return this.strGfileLine;
	}

	/**
	 * Method description
	 * 
	 * @see
	 * @return
	 */
	final public String getReferenceString() {
		return this.strGfileName;
	}

	final public String getTitleString() {
		return this.strGfileTitle;
	}




	final public boolean hasJMFormat() {
		return this.bolGjMFormat;
	}




	final private static long	serialVersionUID	= Constants.lngS_ENGINE_VERSION_NUMBER;

	/**
	 * Method description
	 * 
	 * @see
	 * @param strPcodeBase
	 * @param strPfileName
	 * @return
	 */
	final public static PatternsBufferedReader getNewPatternsBufferedReader(String strPcodeBase, String strPfileName) {
		String strLfileTitle = null;
		if (!Tools.isEmpty(strPfileName)) {
			final int intLlastPathSeparatorIndex =
													Math.max(	Math.max(strPfileName.lastIndexOf('/'), strPfileName.lastIndexOf('\\')),
																strPfileName.lastIndexOf(File.separatorChar));
			if (intLlastPathSeparatorIndex >= 0) {
				strLfileTitle = Strings.getRightDotTrimmedString(strPfileName.substring(intLlastPathSeparatorIndex + 1));
			}
		}
		return PatternsBufferedReader.getNewPatternsBufferedReader(strPcodeBase, strPfileName, strLfileTitle);
	}

	final public static PatternsBufferedReader getNewPatternsBufferedReader(String strPcodeBase,
																			String strPfileName,
																			String strPfileTitle) {

		final boolean bolLjmFormat =
										strPfileName	.toLowerCase()
															.endsWith(Strings.doConcat(	'.',
																								Constants.strS_FILE_EXTENSION_A[Constants.bytS_EXTENSION_JM].toLowerCase()));
		PatternsBufferedReader objLpatternsBufferedReader = null;
		for (byte bytLreferenceIndex = 0; bytLreferenceIndex < 2 && objLpatternsBufferedReader == null; ++bytLreferenceIndex) {
			final String strLfullReference =
													(bytLreferenceIndex == 0) ? strPfileName : Strings.doConcat(strPcodeBase,
																															strPfileName);
			try {
				objLpatternsBufferedReader = new PatternsBufferedReader(new FileReader(strLfullReference), bolLjmFormat);
			} catch (final Throwable objPfirstThrowable) {
				try {
					objLpatternsBufferedReader =
													new PatternsBufferedReader(	new InputStreamReader(new URL(strLfullReference).openStream()),
																				bolLjmFormat);
				} catch (final Throwable objPsecondThrowable) {
					objLpatternsBufferedReader = null;
				}
			}
		}
		if (objLpatternsBufferedReader != null) {
			objLpatternsBufferedReader.strGfileName = new String(strPfileName);
			objLpatternsBufferedReader.strGfileTitle = new String(strPfileTitle);
		} else {
			Tools.errors("Error while trying to open '", strPfileName, "'");
		}
		return objLpatternsBufferedReader;
	}

	private final boolean	bolGjMFormat;

	private boolean			bolGskipNextRead;

	private boolean			bolGskipStyleDefinition;




	private int				intGfileLineIndex;

	private String			strGfileLine;

	private String			strGfileName;

	private String			strGfileTitle;
}

/*
 * @(#)PatternsBufferedReader.java 4.3.0
 * Copyleft (c) 2010 Arnaud BeLO.
 */
