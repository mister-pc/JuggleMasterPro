#!/bin/sh

cd bin
java -cp JuggleAnim.jar JuggleAnim
